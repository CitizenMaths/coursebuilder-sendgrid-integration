# Change Log
All notable changes to this project will be documented in this file.

## [0.3.1] - 2015-10-01
### Added
- Added in support for `Decimal` objects in SMTP API JSON messages (via @jstol)