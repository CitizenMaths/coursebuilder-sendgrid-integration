#!/bin/bash
# Use this to activate the virtual environment, use the following to execute in current shell
# . ./activate
source venv/bin/activate