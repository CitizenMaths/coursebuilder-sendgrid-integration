#!/bin/bash

rm *.pyc
rm tests/*.pyc
rm python_http_client/*.pyc
rm -rf __pycache__/
rm -rf tests/__pycache__/
rm -rf python_http_client/__pycache__/
rm -rf *.egg-info
